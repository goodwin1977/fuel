window.onscroll = function () {
  let scrollElem = document.getElementById("scrollToUp-btn");
  if (window.scrollY > 200) {
    scrollElem.style.opacity = "1";
  } else {
    scrollElem.style.opacity = "0";
  }
}

window.onload = function () {
  let scrolled;
  let timer;

  document.getElementById('scrollToUp-btn').onclick = function () {
    scrolled = window.pageYOffset;
    scrollToTop();
  }

  function scrollToTop() {
    if (scrolled > 0) {
      window.scrollTo(0, scrolled);
      scrolled = scrolled - 100;
      timer = setTimeout(scrollToTop, 30);
    } else {
      clearTimeout(timer);
      window.scrollTo(0, 0);
    }
  }
}